curl http://localhost:8080/admin?shutdown=1000
