mvn compile assembly:single
cp ./target/Java_server.jar ./
