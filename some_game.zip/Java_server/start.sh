java -classpath Java_server.jar Main 8080
